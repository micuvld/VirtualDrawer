class Items < ActiveRecord::Migration[5.0]
  def self.up
	create_table :items do |t|
		t.column :name, :string
		t.column :description, :text
		t.column :created_at, :timestamp
	end
  end
	
  def self.down
	drop_table :items
  end
end
